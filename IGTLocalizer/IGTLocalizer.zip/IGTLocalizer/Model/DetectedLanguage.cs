﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGTLocalizer.Model
{
    class DetectedLanguage
    {
        public int code { get; set; }
        public string lang { get; set; }
    }
}
